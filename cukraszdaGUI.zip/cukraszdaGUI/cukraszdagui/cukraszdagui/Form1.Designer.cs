﻿namespace cukraszdagui
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.kivalasztottsuti = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dijnyertessutik = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.legdragabbsutinev = new System.Windows.Forms.TextBox();
            this.legolcsobbsutinev = new System.Windows.Forms.TextBox();
            this.legdragabbsutiar = new System.Windows.Forms.TextBox();
            this.legolcsobbsutiar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.sutitipusa = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button2 = new System.Windows.Forms.Button();
            this.ujsutinev = new System.Windows.Forms.TextBox();
            this.ujsutitipus = new System.Windows.Forms.TextBox();
            this.ujsutiegyseg = new System.Windows.Forms.TextBox();
            this.ujsutiar = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(146, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(224, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "Árajánlat mentése";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // kivalasztottsuti
            // 
            this.kivalasztottsuti.Location = new System.Drawing.Point(44, 31);
            this.kivalasztottsuti.Name = "kivalasztottsuti";
            this.kivalasztottsuti.Size = new System.Drawing.Size(304, 22);
            this.kivalasztottsuti.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(390, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 124);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // dijnyertessutik
            // 
            this.dijnyertessutik.Location = new System.Drawing.Point(44, 77);
            this.dijnyertessutik.Name = "dijnyertessutik";
            this.dijnyertessutik.Size = new System.Drawing.Size(304, 22);
            this.dijnyertessutik.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Legdrábább süteményünk";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Legolcsóbb süteményünk";
            // 
            // legdragabbsutinev
            // 
            this.legdragabbsutinev.Location = new System.Drawing.Point(7, 184);
            this.legdragabbsutinev.Name = "legdragabbsutinev";
            this.legdragabbsutinev.Size = new System.Drawing.Size(301, 22);
            this.legdragabbsutinev.TabIndex = 6;
            // 
            // legolcsobbsutinev
            // 
            this.legolcsobbsutinev.Location = new System.Drawing.Point(7, 287);
            this.legolcsobbsutinev.Name = "legolcsobbsutinev";
            this.legolcsobbsutinev.Size = new System.Drawing.Size(301, 22);
            this.legolcsobbsutinev.TabIndex = 7;
            // 
            // legdragabbsutiar
            // 
            this.legdragabbsutiar.Location = new System.Drawing.Point(350, 183);
            this.legdragabbsutiar.Name = "legdragabbsutiar";
            this.legdragabbsutiar.Size = new System.Drawing.Size(165, 22);
            this.legdragabbsutiar.TabIndex = 8;
            // 
            // legolcsobbsutiar
            // 
            this.legolcsobbsutiar.Location = new System.Drawing.Point(350, 287);
            this.legolcsobbsutiar.Name = "legolcsobbsutiar";
            this.legolcsobbsutiar.Size = new System.Drawing.Size(165, 22);
            this.legolcsobbsutiar.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 339);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Süti típusa";
            // 
            // sutitipusa
            // 
            this.sutitipusa.Location = new System.Drawing.Point(172, 339);
            this.sutitipusa.Name = "sutitipusa";
            this.sutitipusa.Size = new System.Drawing.Size(343, 22);
            this.sutitipusa.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ujsutiar);
            this.panel1.Controls.Add(this.ujsutiegyseg);
            this.panel1.Controls.Add(this.ujsutitipus);
            this.panel1.Controls.Add(this.ujsutinev);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(576, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(463, 409);
            this.panel1.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Süti neve:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Süti tipusa:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Egység:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "Ár:";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(28, 270);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(77, 21);
            this.checkBox1.TabIndex = 4;
            this.checkBox1.Text = "Díjazott";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(91, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(218, 36);
            this.button2.TabIndex = 5;
            this.button2.Text = "Új süti felvétele";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ujsutinev
            // 
            this.ujsutinev.Location = new System.Drawing.Point(143, 32);
            this.ujsutinev.Name = "ujsutinev";
            this.ujsutinev.Size = new System.Drawing.Size(285, 22);
            this.ujsutinev.TabIndex = 6;
            // 
            // ujsutitipus
            // 
            this.ujsutitipus.Location = new System.Drawing.Point(143, 87);
            this.ujsutitipus.Name = "ujsutitipus";
            this.ujsutitipus.Size = new System.Drawing.Size(285, 22);
            this.ujsutitipus.TabIndex = 7;
            // 
            // ujsutiegyseg
            // 
            this.ujsutiegyseg.Location = new System.Drawing.Point(143, 150);
            this.ujsutiegyseg.Name = "ujsutiegyseg";
            this.ujsutiegyseg.Size = new System.Drawing.Size(285, 22);
            this.ujsutiegyseg.TabIndex = 8;
            // 
            // ujsutiar
            // 
            this.ujsutiar.Location = new System.Drawing.Point(143, 208);
            this.ujsutiar.Name = "ujsutiar";
            this.ujsutiar.Size = new System.Drawing.Size(285, 22);
            this.ujsutiar.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.sutitipusa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.legolcsobbsutiar);
            this.Controls.Add(this.legdragabbsutiar);
            this.Controls.Add(this.legolcsobbsutinev);
            this.Controls.Add(this.legdragabbsutinev);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dijnyertessutik);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.kivalasztottsuti);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Cukrászda";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox kivalasztottsuti;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox dijnyertessutik;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox legdragabbsutinev;
        private System.Windows.Forms.TextBox legolcsobbsutinev;
        private System.Windows.Forms.TextBox legdragabbsutiar;
        private System.Windows.Forms.TextBox legolcsobbsutiar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox sutitipusa;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox ujsutiar;
        private System.Windows.Forms.TextBox ujsutiegyseg;
        private System.Windows.Forms.TextBox ujsutitipus;
        private System.Windows.Forms.TextBox ujsutinev;
    }
}

